$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "ca6704a6-2fb2-4997-a6c0-57325351a5c8",
    "feature": "Login page feature",
    "scenario": "Login page title",
    "start": 1739166425707,
    "group": 1,
    "content": "",
    "tags": "@sanity,",
    "end": 1739166435072,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[#1,main,5,main]"
  }
]);
});