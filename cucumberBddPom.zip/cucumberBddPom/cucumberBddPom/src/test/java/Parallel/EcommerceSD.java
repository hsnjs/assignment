package Parallel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.EcommercePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.After;
import static org.junit.Assert.*;

import java.util.List;

public class EcommerceSD {

    private WebDriver driver;
    private EcommercePage ecommercePage;
  
    // Setup WebDriver instance and initialize the EcommercePage class
    @Given("I am logged in as a standard user")
    public void i_am_logged_in_as_a_standard_user() {
        // Initialize WebDriver (assuming ChromeDriver is used here)
        driver = new ChromeDriver();
        ecommercePage = new EcommercePage(driver);
        
        driver.get("https://demowebshop.tricentis.com/login");  // Replace with actual URL of your e-commerce site
        
        
        // Log in with valid user credentials
        ecommercePage.login("amulyapallapthu@gmail.com","Amulya2001");  // Replace with actual credentials
    }

    // Scenario 1: Add item to shopping cart
    @When("I add an item to the shopping cart {int}")
    public void i_add_an_item_to_the_shopping_cart(int index) {
        ecommercePage.addItemToCart(index); // Add the first product (index) to the cart
    }

    @When("I go to the shopping cart")
    public void i_go_to_the_shopping_cart() {
        ecommercePage.goToCart(); // Navigate to the shopping cart page
    }

    @Then("I should see items in the cart")
    public void i_should_see_items_in_the_cart() {
        boolean isItemInCart = ecommercePage.viewCart();
        assertTrue("Item should be in the cart", isItemInCart);
    }

    // Scenario 2: Shopping cart is empty
    @When("I go to the shopping cart without adding any items")
    public void i_go_to_the_shopping_cart_without_adding_any_items() {
        ecommercePage.viewCart(); // Navigate to the shopping cart without adding any items
    }

    @Then("I should see a message indicating that the cart is empty")
    public void i_should_see_a_message_indicating_that_the_cart_is_empty() {
        boolean isCartEmptyMessageDisplayed = ecommercePage.isWishlistEmpty();
        assertTrue("Empty cart message should be displayed", isCartEmptyMessageDisplayed);
    }

    // Scenario 3: Verify item quantity in the shopping cart
    @When("I add {int} items of a product to the shopping cart")
    public void i_add_items_of_a_product_to_the_shopping_cart(String quantity) {
        ecommercePage.addItemToCart(0); // Add the first product (index 0) to the cart
        // For demonstration, we add another item of the same product
        if (Integer.parseInt(quantity) > 1) {
            ecommercePage.addItemToCart(0);
        }
    }

    @Then("I should see the quantity of the item as {int} in the cart")
    public void i_should_see_the_quantity_of_the_item_as_in_the_cart(int  expectedQuantity) {
      int actualQuantity = ecommercePage.getCartItemQuantity(); // Get the quantity of the first item in the cart
        assertEquals("The quantity of the item should be correct", expectedQuantity, actualQuantity);
    }

    // Scenario 4: Add products to wishlist
    @When("I add a product to my wishlist")
    public void i_add_a_product_to_my_wishlist() {
    	ecommercePage.addProductToWishlist(0); // Add the first product (index 0) to the wishlist
    }

    @Then("I should see the added product in my wishlist")
    public void i_should_see_the_added_product_in_my_wishlist() {
        boolean isProductInWishlist = ecommercePage.isProductInWishlist();
        assertTrue("Product should be in the wishlist", isProductInWishlist);
    }

    // Scenario 5: Wishlist is empty
    @When("I go to the wishlist without adding any products")
    public void i_go_to_the_wishlist_without_adding_any_products() {
        ecommercePage.goToWishlist(); // Navigate to the wishlist without adding any products
    }

    @Then("I should see a message indicating that the wishlist is empty")
    public void i_should_see_a_message_indicating_that_the_wishlist_is_empty() {
        boolean isWishlistEmptyMessageDisplayed = ecommercePage.isWishlistEmpty();
        assertTrue("Empty wishlist message should be displayed", isWishlistEmptyMessageDisplayed);
    }

    // Scenario 6: Verify multiple items in the wishlist
    @When("I add products to the wishlist")
    public void i_add_multiple_products_to_the_wishlist() {
        ecommercePage.addProductToWishlist(0); // Add the first product (index 0) to the wishlist
        ecommercePage.addProductToWishlist(1); // Add the second product (index 1) to the wishlist
    }

    @Then("I should see all the added products in the wishlist")
    public void i_should_see_all_the_added_products_in_the_wishlist() {
        List<String> isAllProductsInWishlist = ecommercePage.getWishlistProductNames();
        System.out.println("All added products should be in the wishlist" +isAllProductsInWishlist);
    }

    // Cleanup method to close the browser after each test
    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}




















































































































































































































































































































































































