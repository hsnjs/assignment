package com.pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EcommercePage {
	
	
	private WebDriver driver;
	
	 // Locators for login
	private By login=By.xpath("//a[@href='/login']");
    private By usernameField = By.id("Email");
    private By passwordField = By.id("Password");
    private By loginButton = By.xpath("//input[@value='Log in']");

    // Locators for shopping cart
    private By cartButton = By.xpath("//span[normalize-space()='Shopping cart']");
    private By cartItemCount = By.id("cartItemCount");

    // Locators for wishlist
    private By wishlistButton = By.id("wishlistButton");
    private By addToWishlistButton = By.id("addToWishlistButton");
    private By wishlistItemCount = By.id("wishlistItemCount");
    private By wishlistEmptyMessage = By.id("wishlistEmptyMessage");
    private By wishlistProductNames = By.cssSelector(".wishlist-product-name");

	private By addToWishlistButtons;

	private WebDriverWait wait;
    
    public EcommercePage(WebDriver driver) {
    	this.driver = driver;
        this.wait = new WebDriverWait(driver, 10); // Adjust timeout as necessary
    }

    // Login methods
    public void login(String username, String password) {
    	

        // Wait for the username field to be visible
        WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField));
        usernameInput.sendKeys(username);

        // Wait for the password field to be visible
        WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField));
        passwordInput.sendKeys(password);
        System.out.println(username);
        System.out.println(password);
        // Wait for the login button to be clickable and then click it
        WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(loginButton));
        loginBtn.click();
    }

    // Cart methods
    public void addItemToCart(int index) {
        // Create a dynamic XPath using concatenation for the index value
        String xpath = "(//input[@value='Add to cart'])[" + index + "]";

        // Wait for the 'Add to Cart' button to be clickable
        WebElement addToCartButton = new WebDriverWait(driver, 10)  // 10 seconds timeout (adjust as necessary)
            .until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        
        // Click the button once it's clickable
        addToCartButton.click();
    }

    

    public void goToCart() {
    	
        driver.findElement(cartButton).click();
    }
    
    public boolean viewCart() {
		driver.findElement(By.xpath("//h1[normalize-space()='Build your own computer']"));
		return false;
	}

    public boolean isCartEmpty() {
        String itemCountText = driver.findElement(cartItemCount).getText();
        return itemCountText.equals("0");
    }

    // Wishlist methods
    public void addProductToWishlist(int index) {
       
    	 WebElement addToWishlistBtn = driver.findElement(addToWishlistButton);
         addToWishlistBtn.click();
    }

    public void goToWishlist() {
        driver.findElement(wishlistButton).click();
    }

    public boolean isWishlistEmpty() {
        try {
            WebElement emptyMessage = driver.findElement(wishlistEmptyMessage);
            return emptyMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public List<String> getWishlistProductNames() {
        List<WebElement> productElements = driver.findElements(wishlistProductNames);
        return productElements.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

	

	public int getCartItemQuantity() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean isProductInWishlist() {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}

    

	
	
	
	